import pygame
import random
import math
from pygame import mixer
# Initialize the pygame
pygame.init()
mixer.init()

# Create the Screen
main_screen = pygame.display.set_mode((500, 400))

# Title, Logo
pygame.display.set_caption("Space Shuttle")
logo_main = pygame.image.load('images/Logo.ico')
pygame.display.set_icon(logo_main)

# Players
home_image = pygame.image.load('images/spaceship.png')
home_imageX = 200
home_imageY = 330
value_change = 0

# Enemy
enemy_image = []
enemy_imageX = []
enemy_imageY = []
enemyX_change = []
enemyY_change = []
num_enemies = 6

for i in range(num_enemies):
    enemy_image.append(pygame.image.load('images/enemy.png'))
    enemy_imageX.append(random.randint(0, 468))
    enemy_imageY.append(random.randint(30, 200))
    enemyX_change.append(0.3)
    enemyY_change.append(10)

# Bullet Values
bullet_image = pygame.image.load('images/bullet.png')
bullet_imageX = 0
bullet_imageY = 330
bullet_changeX = 0
bullet_changeY = 1
bullet_fire = 'rest'

#Display Score
score = 0
font_score = pygame.font.Font('freesansbold.ttf', 16)
score_X = 10
score_Y = 10

# Message Game Over
font_message = pygame.font.Font('freesansbold.ttf', 32)
message_X = 72
message_Y = 200

# Background music
mixer.music.load('sound/background.wav')
mixer.music.play(-1)

def set_score(x, y):
    score_render = font_score.render(f'Score: {score}', True, (255, 255, 255))
    main_screen.blit(score_render, (x,y))

def player(x, y):
    main_screen.blit(home_image, (x, y))


def enemy(x, y, i):
    main_screen.blit(enemy_image[i], (x, y))


def bullet(x, y):
    global bullet_fire
    bullet_fire = 'motion'
    main_screen.blit(bullet_image, (x + 17, y - 10))


def iscollide(enemyX, enemyY, bulletX, bulletY):
    distance = math.sqrt((math.pow(bulletX - enemyX, 2)) + (math.pow(bulletY - enemyY, 2)))
    if distance <= 30.0:
        mixer.Sound('sound/explosion.wav').play()
        return True

def game_over(x, y):
    score_render = font_message.render('GAME OVER', True, (255, 255, 255))
    main_screen.blit(score_render, (x, y))



# run loop until quit


running = True
while running:
    main_screen.fill((53, 61, 55))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # Movement player
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                value_change = -0.4
            elif event.key == pygame.K_RIGHT:
                value_change = 0.4
            elif event.key == pygame.K_SPACE:
                if bullet_fire is 'rest':
                    mixer.Sound('sound/laser.wav').play()
                    bullet_imageX = home_imageX
                    bullet(bullet_imageX, bullet_imageY)
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                value_change = 0


    # Boundary for player
    home_imageX += value_change
    if home_imageX <= 0:
        home_imageX = 0
    elif home_imageX >= 436:
        home_imageX = 436

    # Boundary for Enemy
    for i in range(num_enemies):
        if enemy_imageY[i] >= 300:
            for j in range(num_enemies):
                enemy_imageY[j] = 2000
            game_over(message_X, message_Y)
            break
        enemy_imageX[i] += enemyX_change[i]
        if enemy_imageX[i] <= 0:
            enemyX_change[i] = 0.3
            enemy_imageY[i] += enemyY_change[i]
        elif enemy_imageX[i] >= 468:
            enemyX_change[i] = -0.3
            enemy_imageY[i] += enemyY_change[i]
        result = iscollide(enemy_imageX[i], enemy_imageY[i], bullet_imageX, bullet_imageY)
        if result:
            bullet_imageY = 330
            bullet_fire = 'rest'
            score += 1
            enemy_imageX[i] = random.randint(0, 468)
            enemy_imageY[i] = random.randint(30, 200)
            print(score)
        enemy(enemy_imageX[i], enemy_imageY[i], i)

    # For Bullet
    if bullet_imageY <= 0:
        bullet_imageY = 330
        bullet_fire = 'rest'
    if bullet_fire is 'motion':
        bullet(bullet_imageX, bullet_imageY)
        bullet_imageY -= bullet_changeY

    player(home_imageX, home_imageY)
    set_score(score_X, score_Y)

    pygame.display.update()


